http://dojopuzzles.com/problemas/exibe/jokenpo/
atividadeproposta